import { useState, useEffect } from 'react';

const DEFAULTS = {
  lang: 'mixed',
  agentCount: 5,
  notionDbId: '',
  n8nWebhookId: '',
  n8nAutoSend: false,
  notionAutoSave: false,
};

export function useSettings() {
  const [settings, setSettingsRaw] = useState(() => {
    try {
      const stored = localStorage.getItem('oracle_settings');
      return stored ? { ...DEFAULTS, ...JSON.parse(stored) } : DEFAULTS;
    } catch { return DEFAULTS; }
  });

  const setSettings = (patch) => {
    setSettingsRaw(prev => {
      const next = { ...prev, ...patch };
      try { localStorage.setItem('oracle_settings', JSON.stringify(next)); } catch {}
      return next;
    });
  };

  return [settings, setSettings];
}
