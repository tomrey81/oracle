import { useState } from 'react';

export function useSessions() {
  const [sessions, setSessions] = useState(() => {
    try {
      const stored = localStorage.getItem('oracle_sessions');
      return stored ? JSON.parse(stored) : [];
    } catch { return []; }
  });

  const addSession = (session) => {
    setSessions(prev => {
      const next = [session, ...prev].slice(0, 30);
      try { localStorage.setItem('oracle_sessions', JSON.stringify(next)); } catch {}
      return next;
    });
  };

  const clearSessions = () => {
    setSessions([]);
    try { localStorage.removeItem('oracle_sessions'); } catch {}
  };

  return { sessions, addSession, clearSessions };
}
