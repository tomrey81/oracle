// ─── NOTION INTEGRATION ──────────────────────────────────────────────────────
// Stores Oracle sessions as Notion pages in a configured database.
// Env var NOTION_DB_ID must be set in Vercel (the Oracle Sessions database ID).

async function notionRequest(method, path, body) {
  const res = await fetch('/api/notion', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ method, path, body }),
  });
  if (!res.ok) {
    const e = await res.json().catch(() => ({}));
    throw new Error(e?.message || `Notion error ${res.status}`);
  }
  return res.json();
}

// Convert a session to a Notion page
export async function exportSessionToNotion(session, dbId) {
  if (!dbId) throw new Error('NOTION_DB_ID not configured');

  const { sid, query, turns, synthesis, meta } = session;

  // Build rich text blocks from deliberation turns
  const turnBlocks = turns.map(t => ({
    object: 'block',
    type: 'callout',
    callout: {
      rich_text: [
        { type: 'text', text: { content: `${t.glyph} ${t.name} / ${t.role}\n${t.text}` } }
      ],
      icon: { type: 'emoji', emoji: agentEmoji(t.agentId) },
      color: agentColor(t.agentId),
    }
  }));

  // Synthesis block
  const synthBlock = synthesis ? {
    object: 'block',
    type: 'quote',
    quote: {
      rich_text: [{ type: 'text', text: { content: synthesis } }],
      color: 'purple_background',
    }
  } : null;

  const page = await notionRequest('POST', 'pages', {
    parent: { database_id: dbId },
    icon: { type: 'emoji', emoji: '⚖️' },
    properties: {
      Name: {
        title: [{ type: 'text', text: { content: `Oracle ${sid}` } }]
      },
      Query: {
        rich_text: [{ type: 'text', text: { content: query } }]
      },
      Session: {
        rich_text: [{ type: 'text', text: { content: sid } }]
      },
      Agents: {
        rich_text: [{ type: 'text', text: { content: meta?.agents || '' } }]
      },
      Language: {
        select: { name: meta?.lang || 'Mixed' }
      },
      Confidence: {
        select: { name: extractConfidence(synthesis) }
      },
      Date: {
        date: { start: new Date().toISOString() }
      },
    },
    children: [
      { object: 'block', type: 'heading_2', heading_2: { rich_text: [{ type: 'text', text: { content: '📋 Question' } }] } },
      { object: 'block', type: 'paragraph', paragraph: { rich_text: [{ type: 'text', text: { content: query } }] } },
      { object: 'block', type: 'divider', divider: {} },
      { object: 'block', type: 'heading_2', heading_2: { rich_text: [{ type: 'text', text: { content: '⚙️ Deliberation' } }] } },
      ...turnBlocks,
      { object: 'block', type: 'divider', divider: {} },
      { object: 'block', type: 'heading_2', heading_2: { rich_text: [{ type: 'text', text: { content: 'Σ Synthesis' } }] } },
      ...(synthBlock ? [synthBlock] : []),
    ].filter(Boolean),
  });

  return page;
}

// Fetch recent Oracle sessions from Notion DB
export async function fetchSessionsFromNotion(dbId) {
  if (!dbId) return [];
  const data = await notionRequest('POST', `databases/${dbId}/query`, {
    sorts: [{ property: 'Date', direction: 'descending' }],
    page_size: 20,
  });
  return (data.results || []).map(page => ({
    sid: page.properties?.Session?.rich_text?.[0]?.text?.content || page.id,
    query: page.properties?.Query?.rich_text?.[0]?.text?.content || '',
    notionUrl: page.url,
    date: page.properties?.Date?.date?.start,
  }));
}

function extractConfidence(text) {
  if (!text) return 'Unknown';
  const m = text.match(/\b(WYSOKI|WYSOKA|HIGH)\b/i);
  if (m) return 'HIGH';
  const m2 = text.match(/\b(ŚREDNI|ŚREDNIA|MEDIUM)\b/i);
  if (m2) return 'MEDIUM';
  const m3 = text.match(/\b(NISKI|NISKA|LOW)\b/i);
  if (m3) return 'LOW';
  return 'Unknown';
}

function agentEmoji(id) {
  return { architect:'🏛️', analyst:'📊', challenger:'⚔️', builder:'🔨', synthesiser:'⚖️' }[id] || '💬';
}

function agentColor(id) {
  return { architect:'blue_background', analyst:'green_background', challenger:'red_background', builder:'yellow_background', synthesiser:'purple_background' }[id] || 'default';
}
