// ─── N8N INTEGRATION ─────────────────────────────────────────────────────────
// Two modes:
// 1. TRIGGER: Send Oracle session output to an n8n webhook
// 2. RECEIVE: Oracle is triggered BY n8n (handled via URL params on load)

export async function sendToN8n(webhookId, session) {
  if (!webhookId) throw new Error('No webhook ID provided');

  const { sid, query, turns, synthesis, meta } = session;

  const payload = {
    // Decision Ledger compatible format
    oracle_session: {
      session_id: sid,
      timestamp: new Date().toISOString(),
      query,
      language: meta?.lang,
      agents: meta?.agents,
      duration_seconds: meta?.dur,
      confidence: extractConfidence(synthesis),
      turns: turns.map(t => ({
        agent_id: t.agentId,
        agent_name: t.name,
        role: t.role,
        text: t.text,
        timestamp: t.ts,
      })),
      synthesis,
      first_action: extractFirstAction(synthesis),
    },
    // Flat fields for easy n8n mapping
    session_id: sid,
    query,
    synthesis,
    confidence: extractConfidence(synthesis),
    first_action: extractFirstAction(synthesis),
    timestamp: new Date().toISOString(),
  };

  const res = await fetch('/api/n8n', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ webhookId, payload }),
  });

  if (!res.ok) {
    const e = await res.json().catch(() => ({}));
    throw new Error(e?.error || `n8n error ${res.status}`);
  }
  return res.json();
}

// Check URL params for n8n-triggered session
// n8n can open Oracle with: ?n8n_query=...&n8n_webhook=...&n8n_lang=...
export function parseN8nTrigger() {
  const params = new URLSearchParams(window.location.search);
  const query = params.get('n8n_query');
  if (!query) return null;
  return {
    query: decodeURIComponent(query),
    webhookReturn: params.get('n8n_webhook') || '',
    lang: params.get('n8n_lang') || 'mixed',
    agents: parseInt(params.get('n8n_agents') || '5', 10),
    autoStart: params.get('n8n_auto') === '1',
  };
}

function extractConfidence(text) {
  if (!text) return 'UNKNOWN';
  if (/\b(WYSOKI|WYSOKA|HIGH)\b/i.test(text)) return 'HIGH';
  if (/\b(ŚREDNI|ŚREDNIA|MEDIUM)\b/i.test(text)) return 'MEDIUM';
  if (/\b(NISKI|NISKA|LOW)\b/i.test(text)) return 'LOW';
  return 'UNKNOWN';
}

function extractFirstAction(text) {
  if (!text) return '';
  // Look for PIERWSZE DZIAŁANIE or FIRST ACTION block
  const m = text.match(/\[(?:PIERWSZE DZIAŁANIE|FIRST ACTION)\]\s*\n([^\[]+)/i);
  if (m) return m[1].trim();
  return '';
}
