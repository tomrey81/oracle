import { useState, useRef, useEffect, useCallback } from 'react';
import { callAgent } from './api/oracle.js';
import { exportSessionToNotion, fetchSessionsFromNotion } from './api/notion.js';
import { sendToN8n, parseN8nTrigger } from './api/n8n.js';
import { useSettings } from './hooks/useSettings.js';
import { useSessions } from './hooks/useSessions.js';

// ─── AGENTS ──────────────────────────────────────────────────────────────────
const AGENTS = [
  {
    id: 'architect', glyph: 'Ⅰ', hue: '#3A8FA8',
    name: { en: 'Architect', pl: 'Architekt' },
    role: { en: 'Problem Framing', pl: 'Kadrowanie' },
    emoji: '🏛️',
    persona: (lang) => lang === 'pl'
      ? `Jesteś Architektem w radzie The Oracle (Quadrance). Precyzyjnie kadruj problem. Otwórz deliberację przeformułowując pytanie jako stwierdzenie + 3 podpytania. Styl: sokratejski, zwięzły. Max 200 słów.`
      : `You are The Architect on The Oracle council (Quadrance). Frame problems precisely. Open deliberation by restating the question as a crisp problem statement + 3 sub-questions. Style: Socratic, concise. Max 200 words.`,
  },
  {
    id: 'analyst', glyph: 'Ⅱ', hue: '#2E9E68',
    name: { en: 'Analyst', pl: 'Analityk' },
    role: { en: 'Evidence & Data', pl: 'Dane' },
    emoji: '📊',
    persona: (lang) => lang === 'pl'
      ? `Jesteś Analitykiem w radzie The Oracle (Quadrance). Ugruntowuj debatę w faktach i liczbach. Zawsze podaj co najmniej jeden konkretny punkt danych. Styl: empiryczny. Max 200 słów.`
      : `You are The Analyst on The Oracle council (Quadrance). Ground debate in facts and numbers. Always include at least one specific data point. Style: Empirical, precise. Max 200 words.`,
  },
  {
    id: 'challenger', glyph: 'Ⅲ', hue: '#C05A3A',
    name: { en: 'Challenger', pl: 'Challenger' },
    role: { en: 'Critique', pl: 'Krytyka' },
    emoji: '⚔️',
    persona: (lang) => lang === 'pl'
      ? `Jesteś Challengerem w radzie The Oracle (Quadrance). Adwokat diabła. Zgłoś co najmniej jedną merytoryczną obiekcję. Kwestionuj kadrowanie i dane. Zakończ konkretnym pytaniem. Max 180 słów.`
      : `You are The Challenger on The Oracle council (Quadrance). Devil's advocate. Raise at least one substantive objection. Challenge framing and data. End with a specific question. Max 180 words.`,
  },
  {
    id: 'builder', glyph: 'Ⅳ', hue: '#B8860B',
    name: { en: 'Builder', pl: 'Budowniczy' },
    role: { en: 'Action', pl: 'Działanie' },
    emoji: '🔨',
    persona: (lang) => lang === 'pl'
      ? `Jesteś Budowniczym w radzie The Oracle (Quadrance). Pragmatyk. Przekształcaj debatę w działanie. Zakończ konkretną sekwencją kroków. Max 200 słów.`
      : `You are The Builder on The Oracle council (Quadrance). The pragmatist. Translate debate into action. End with a concrete sequence of next steps. Max 200 words.`,
  },
  {
    id: 'synthesiser', glyph: 'Σ', hue: '#6B5EA8',
    name: { en: 'Synthesiser', pl: 'Syntezator' },
    role: { en: 'Recommendation', pl: 'Rekomendacja' },
    emoji: '⚖️',
    persona: (lang) => lang === 'pl'
      ? `Jesteś Syntezatorem w radzie The Oracle (Quadrance). Mówisz ostatni. Użyj tej struktury:

[REKOMENDACJA GŁÓWNA]
Jedno zdanie.

[UZASADNIENIE]
2–3 zdania odwołujące się do deliberacji.

[KLUCZOWE ZAŁOŻENIE]
Co musi być prawdą.

[POZIOM PEWNOŚCI]
WYSOKI / ŚREDNI / NISKI + jedno zdanie.

[PIERWSZE DZIAŁANIE]
Co zrobić w ciągu 48 godzin.

[NAJSILNIEJSZA OBIEKCJA]
Przyznaj ją i wyjaśnij dlaczego rekomendacja mimo to jest słuszna.

Max 300 słów.`
      : `You are The Synthesiser on The Oracle council (Quadrance). You speak last. Use this exact structure:

[CORE RECOMMENDATION]
One sentence.

[REASONING]
2–3 sentences referencing the deliberation.

[KEY ASSUMPTION]
What must be true.

[CONFIDENCE]
HIGH / MEDIUM / LOW + one sentence.

[FIRST ACTION]
What to do within 48 hours.

[STRONGEST OBJECTION]
Acknowledge it and explain why the recommendation holds.

Max 300 words.`,
  },
];

const PRESETS = {
  3: ['architect', 'challenger', 'synthesiser'],
  4: ['architect', 'analyst', 'challenger', 'synthesiser'],
  5: ['architect', 'analyst', 'challenger', 'builder', 'synthesiser'],
};

const LANGS = [
  { v: 'pl', label: 'Polski', flag: '🇵🇱' },
  { v: 'en', label: 'English', flag: '🇬🇧' },
  { v: 'mixed', label: 'Mixed', flag: '⚗️' },
];

// ─── STYLES ──────────────────────────────────────────────────────────────────
const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400&family=JetBrains+Mono:wght@300;400;500&display=swap');

*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
:root{
  --navy:#0F1E30; --navy2:#131F2C; --navy3:#1A2B3C;
  --teal:#0B7A84; --teal2:#0E9AA6; --tealA:rgba(11,122,132,0.15);
  --gold:#B8860B; --goldL:#D4A017; --goldA:rgba(184,134,11,0.12);
  --text:#C8D4DC; --textD:#6A7E8E; --textDD:#3A4E5E;
  --border:#1E2E3E; --border2:#263444;
  --white:#E8EEF2; --surface:#111C28; --surf2:#0C1520;
  --red:#C05A3A; --green:#2E9E68; --purple:#6B5EA8;
  --safe-top: env(safe-area-inset-top, 0px);
  --safe-bot: env(safe-area-inset-bottom, 0px);
}
html,body,#root{height:100%;overflow:hidden;}
body{background:var(--navy);color:var(--text);font-family:'Plus Jakarta Sans',sans-serif;-webkit-font-smoothing:antialiased;}

/* ── SHELL ── */
.shell{display:flex;flex-direction:column;height:100%;height:100dvh;overflow:hidden;}

/* ── TOPBAR ── */
.topbar{
  flex-shrink:0;
  padding:calc(var(--safe-top) + 10px) 16px 10px;
  background:var(--surf2);
  border-bottom:1px solid var(--border);
  display:flex;align-items:center;gap:10px;
}
.brand{display:flex;align-items:center;gap:8px;flex:1;}
.brand-q{
  width:32px;height:32px;border-radius:8px;flex-shrink:0;
  background:linear-gradient(135deg,var(--teal),var(--navy3));
  border:1px solid var(--teal);
  display:flex;align-items:center;justify-content:center;
  font-size:14px;font-weight:700;color:var(--white);
  box-shadow:0 0 16px -5px var(--teal);
}
.brand-text{display:flex;flex-direction:column;}
.brand-name{font-size:13px;font-weight:600;letter-spacing:0.05em;color:var(--white);}
.brand-sub{font-family:'JetBrains Mono',monospace;font-size:9px;letter-spacing:0.14em;text-transform:uppercase;color:var(--teal2);}
.icon-btn{
  width:36px;height:36px;border-radius:8px;
  border:1px solid var(--border2);background:transparent;
  display:flex;align-items:center;justify-content:center;
  color:var(--textD);font-size:16px;cursor:pointer;
  transition:all .15s;flex-shrink:0;
}
.icon-btn:hover{border-color:var(--teal);color:var(--teal2);}
.icon-btn.active{border-color:var(--teal);background:var(--tealA);color:var(--teal2);}

/* ── SESSION BAR ── */
.session-bar{
  flex-shrink:0;padding:8px 16px;
  background:var(--surf2);border-bottom:1px solid var(--border);
  display:flex;align-items:center;gap:6px;overflow-x:auto;
  scrollbar-width:none;
}
.session-bar::-webkit-scrollbar{display:none;}
.sbar-label{
  font-family:'JetBrains Mono',monospace;font-size:9px;
  text-transform:uppercase;letter-spacing:0.1em;color:var(--textDD);
  white-space:nowrap;flex-shrink:0;
}
.sbar-chip{
  font-family:'JetBrains Mono',monospace;font-size:9px;
  padding:4px 9px;border-radius:5px;
  border:1px solid var(--border2);color:var(--textD);
  cursor:pointer;white-space:nowrap;flex-shrink:0;
  transition:all .15s;
}
.sbar-chip:hover{border-color:var(--teal);color:var(--teal2);}
.sbar-chip.notion{border-color:var(--purple);color:var(--purple);opacity:0.7;}

/* ── MAIN SCROLL ── */
.main{flex:1;overflow-y:auto;padding:16px 16px 8px;scrollbar-width:thin;scrollbar-color:var(--border2) transparent;}
.main::-webkit-scrollbar{width:3px;}
.main::-webkit-scrollbar-thumb{background:var(--border2);}

/* ── QUERY AREA ── */
.qarea{flex-shrink:0;padding:12px 16px;background:var(--surf2);border-top:1px solid var(--border);}
.qrow{display:flex;gap:8px;align-items:flex-end;}
textarea.qi{
  flex:1;background:var(--navy);border:1px solid var(--border2);
  border-radius:10px;color:var(--white);
  font-family:'Plus Jakarta Sans',sans-serif;font-size:15px;line-height:1.5;
  padding:11px 14px;resize:none;outline:none;
  min-height:48px;max-height:140px;
  transition:border-color .18s;
}
textarea.qi:focus{border-color:var(--teal);}
textarea.qi::placeholder{color:var(--textDD);font-style:italic;}
textarea.qi:disabled{opacity:0.5;}
.send-btn{
  width:48px;height:48px;border-radius:10px;flex-shrink:0;
  background:linear-gradient(135deg,#0A2535,#0B1E2C);
  border:1px solid var(--gold);color:var(--gold);
  font-size:20px;cursor:pointer;
  display:flex;align-items:center;justify-content:center;
  transition:all .2s;
}
.send-btn:hover:not(:disabled){box-shadow:0 0 20px -5px var(--goldL);}
.send-btn:disabled{opacity:0.3;cursor:not-allowed;}

/* controls row */
.crow{display:flex;align-items:center;gap:8px;margin-bottom:10px;flex-wrap:wrap;}
.sel{
  background:var(--navy);border:1px solid var(--border2);
  color:var(--text);font-family:'JetBrains Mono',monospace;font-size:11px;
  padding:5px 9px;border-radius:6px;cursor:pointer;outline:none;
}
.sel:focus{border-color:var(--teal);}
.pills{display:flex;gap:4px;}
.pill{
  width:28px;height:28px;border-radius:6px;
  border:1px solid var(--border2);
  display:flex;align-items:center;justify-content:center;
  font-family:'JetBrains Mono',monospace;font-size:11px;font-weight:500;
  color:var(--textD);cursor:pointer;transition:all .15s;
}
.pill.on{border-color:var(--teal);color:var(--teal);background:var(--tealA);}
.agent-glyphs{display:flex;gap:3px;}
.ag{
  font-family:'JetBrains Mono',monospace;font-size:9px;
  padding:2px 6px;border-radius:4px;
  border:1px solid var(--a-hue);color:var(--a-hue);opacity:0.7;
}

/* ── TURNS ── */
.turn{display:flex;gap:10px;margin-bottom:20px;animation:up .35s ease both;}
@keyframes up{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}
.turn-left{display:flex;flex-direction:column;align-items:center;flex-shrink:0;width:28px;}
.t-badge{
  width:28px;height:28px;border-radius:7px;
  border:1px solid var(--a-hue);background:var(--surf2);
  display:flex;align-items:center;justify-content:center;
  font-family:'JetBrains Mono',monospace;font-size:10px;font-weight:500;
  color:var(--a-hue);box-shadow:0 0 10px -5px var(--a-hue);
}
.t-thread{width:1px;flex:1;min-height:8px;margin-top:3px;background:linear-gradient(to bottom,var(--a-hue),transparent);opacity:0.15;}
.t-body{flex:1;min-width:0;}
.t-meta{display:flex;align-items:center;gap:6px;margin-bottom:6px;}
.t-name{font-family:'JetBrains Mono',monospace;font-size:10px;font-weight:500;letter-spacing:0.06em;text-transform:uppercase;color:var(--a-hue);}
.t-role{font-family:'JetBrains Mono',monospace;font-size:9px;color:var(--textD);}
.t-ts{margin-left:auto;font-family:'JetBrains Mono',monospace;font-size:9px;color:var(--textDD);}
.t-text{font-size:15px;line-height:1.75;color:var(--text);white-space:pre-wrap;word-break:break-word;}

/* ── SYNTHESIS CARD ── */
.synth-card{
  background:var(--surf2);border:1px solid var(--purple);
  border-radius:12px;padding:16px;margin-bottom:20px;
  animation:up .4s ease both;
  box-shadow:0 0 30px -10px var(--purple);
}
.synth-head{display:flex;align-items:center;gap:8px;margin-bottom:12px;}
.synth-icon{
  width:28px;height:28px;border-radius:7px;border:1px solid var(--purple);background:var(--surf2);
  display:flex;align-items:center;justify-content:center;
  font-family:'JetBrains Mono',monospace;font-size:12px;color:var(--purple);
}
.synth-title{font-family:'JetBrains Mono',monospace;font-size:10px;text-transform:uppercase;letter-spacing:0.1em;color:#8B7EC8;}
.synth-id{margin-left:auto;font-family:'JetBrains Mono',monospace;font-size:9px;padding:2px 7px;border-radius:4px;border:1px solid var(--border2);color:var(--textD);}
.synth-text{font-size:15px;line-height:1.8;color:#C4C8D0;white-space:pre-wrap;}
.synth-meta{margin-top:12px;padding-top:10px;border-top:1px solid var(--border);font-family:'JetBrains Mono',monospace;font-size:9px;color:var(--textD);line-height:1.9;}

/* ── EXPORT ROW ── */
.export-row{display:flex;gap:8px;margin-top:10px;flex-wrap:wrap;}
.exp-btn{
  flex:1;min-width:0;padding:8px 12px;border-radius:8px;
  border:1px solid var(--border2);background:var(--navy);
  font-family:'JetBrains Mono',monospace;font-size:10px;
  letter-spacing:0.05em;color:var(--textD);cursor:pointer;
  display:flex;align-items:center;justify-content:center;gap:6px;
  transition:all .18s;text-align:center;
}
.exp-btn:hover:not(:disabled){border-color:var(--teal);color:var(--teal2);}
.exp-btn:disabled{opacity:0.4;cursor:not-allowed;}
.exp-btn.notion:hover:not(:disabled){border-color:var(--purple);color:var(--purple);}
.exp-btn.n8n:hover:not(:disabled){border-color:var(--gold);color:var(--goldL);}
.exp-btn.success{border-color:var(--green);color:var(--green);}
.exp-btn.error{border-color:var(--red);color:var(--red);}

/* ── THINKING ── */
.thinking{display:flex;gap:10px;margin-bottom:14px;animation:up .25s ease both;}
.dots{display:flex;gap:5px;align-items:center;padding:8px 0;}
.dot{width:4px;height:4px;border-radius:50%;background:var(--a-hue);opacity:0.2;animation:pulse 1.2s ease-in-out infinite;}
.dot:nth-child(2){animation-delay:.13s}.dot:nth-child(3){animation-delay:.26s}
@keyframes pulse{0%,100%{opacity:.15;transform:scale(.7)}50%{opacity:.9;transform:scale(1.1)}}
.think-lbl{font-family:'JetBrains Mono',monospace;font-size:10px;color:var(--textD);margin-left:6px;}

/* ── EMPTY ── */
.empty{display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:220px;gap:12px;opacity:0.25;}
.empty-icon{font-size:40px;}
.empty-txt{font-family:'JetBrains Mono',monospace;font-size:10px;letter-spacing:0.1em;text-transform:uppercase;color:var(--textD);text-align:center;line-height:1.9;}

/* ── DRAWER ── */
.drawer-overlay{
  position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:100;
  animation:fadeIn .2s ease;
}
@keyframes fadeIn{from{opacity:0}to{opacity:1}}
.drawer{
  position:fixed;right:0;top:0;bottom:0;width:300px;max-width:90vw;
  background:var(--surf2);border-left:1px solid var(--border);
  z-index:101;overflow-y:auto;
  padding:calc(var(--safe-top) + 16px) 20px calc(var(--safe-bot) + 20px);
  animation:slideIn .25s ease;
}
@keyframes slideIn{from{transform:translateX(100%)}to{transform:none}}
.drawer-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:24px;}
.drawer-title{font-family:'JetBrains Mono',monospace;font-size:11px;text-transform:uppercase;letter-spacing:0.12em;color:var(--white);}
.close-btn{background:none;border:none;color:var(--textD);font-size:20px;cursor:pointer;padding:4px;}

.section-label{font-family:'JetBrains Mono',monospace;font-size:9px;text-transform:uppercase;letter-spacing:0.12em;color:var(--teal2);margin-bottom:8px;margin-top:20px;}
.field-label{font-family:'JetBrains Mono',monospace;font-size:10px;color:var(--textD);margin-bottom:4px;margin-top:12px;}
input.dinput,textarea.dinput{
  width:100%;background:var(--navy);border:1px solid var(--border2);
  border-radius:6px;color:var(--white);font-family:'JetBrains Mono',monospace;
  font-size:12px;padding:8px 11px;outline:none;
  transition:border-color .15s;
}
input.dinput:focus,textarea.dinput:focus{border-color:var(--teal);}
input.dinput::placeholder,textarea.dinput::placeholder{color:var(--textDD);}

.toggle-row{display:flex;align-items:center;justify-content:space-between;margin-top:12px;}
.toggle-label{font-family:'JetBrains Mono',monospace;font-size:10px;color:var(--textD);}
.toggle{
  width:36px;height:20px;border-radius:10px;
  background:var(--border2);border:none;cursor:pointer;
  position:relative;transition:background .2s;
}
.toggle.on{background:var(--teal);}
.toggle::after{
  content:'';position:absolute;top:3px;left:3px;
  width:14px;height:14px;border-radius:50%;background:white;
  transition:transform .2s;
}
.toggle.on::after{transform:translateX(16px);}

.save-btn{
  width:100%;margin-top:20px;padding:11px;border-radius:8px;
  background:linear-gradient(135deg,var(--teal),#096870);
  border:none;color:var(--white);font-family:'JetBrains Mono',monospace;
  font-size:11px;letter-spacing:0.1em;text-transform:uppercase;
  cursor:pointer;transition:opacity .2s;
}
.save-btn:hover{opacity:0.85;}

.hint{font-family:'JetBrains Mono',monospace;font-size:9px;color:var(--textDD);line-height:1.6;margin-top:4px;}

/* ── TOAST ── */
.toast{
  position:fixed;bottom:calc(var(--safe-bot) + 80px);left:50%;
  transform:translateX(-50%);
  background:var(--navy3);border:1px solid var(--border2);
  border-radius:8px;padding:10px 16px;
  font-family:'JetBrains Mono',monospace;font-size:11px;color:var(--text);
  white-space:nowrap;z-index:200;
  animation:toastIn .3s ease,toastOut .3s ease 2.7s forwards;
  pointer-events:none;
}
.toast.ok{border-color:var(--green);color:var(--green);}
.toast.err{border-color:var(--red);color:var(--red);}
@keyframes toastIn{from{opacity:0;transform:translateX(-50%) translateY(10px)}to{opacity:1;transform:translateX(-50%) translateY(0)}}
@keyframes toastOut{to{opacity:0;transform:translateX(-50%) translateY(10px)}}

/* ── STATUS ── */
.sdot{width:6px;height:6px;border-radius:50%;background:var(--teal);animation:blink 1.4s ease-in-out infinite;}
@keyframes blink{0%,100%{opacity:0.2}50%{opacity:1}}

.divider{height:1px;background:var(--border);margin:8px 0;}
.err-bar{font-family:'JetBrains Mono',monospace;font-size:10px;color:var(--red);padding:6px 16px;background:#160A08;border-bottom:1px solid #2A1210;}

pb{padding-bottom:calc(var(--safe-bot) + 16px);display:block;}
`;

// ─── MAIN COMPONENT ───────────────────────────────────────────────────────────
export default function App() {
  const [settings, setSettings]   = useSettings();
  const { sessions, addSession, clearSessions } = useSessions();

  const [lang, setLang]           = useState(settings.lang);
  const [count, setCount]         = useState(settings.agentCount);
  const [query, setQuery]         = useState('');
  const [running, setRunning]     = useState(false);
  const [turns, setTurns]         = useState([]);
  const [thinking, setThinking]   = useState(null);
  const [synthesis, setSynthesis] = useState(null);
  const [synthMeta, setSynthMeta] = useState(null);
  const [error, setError]         = useState('');
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [draftSettings, setDraft] = useState(settings);
  const [toast, setToast]         = useState(null); // {msg, type}
  const [exportState, setExportState] = useState({}); // {notion:'loading'|'ok'|'err', n8n:...}
  const [currentSession, setCurrentSession] = useState(null);

  const bottomRef = useRef(null);
  const mainRef   = useRef(null);

  // Handle n8n trigger on load
  useEffect(() => {
    const trigger = parseN8nTrigger();
    if (trigger) {
      setQuery(trigger.query);
      if (trigger.lang) setLang(trigger.lang);
      if (trigger.agents) setCount(trigger.agents);
      if (trigger.autoStart) setTimeout(() => conveneRef.current?.(), 500);
    }
  }, []);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [turns, thinking]);

  const conveneRef = useRef(null);

  const agentLang = (id) => {
    if (lang === 'pl') return 'pl';
    if (lang === 'en') return 'en';
    return id === 'synthesiser' ? 'pl' : 'en';
  };

  const activeAgents = () =>
    (PRESETS[count] || PRESETS[5]).map(id => AGENTS.find(a => a.id === id));

  const convene = async () => {
    if (!query.trim() || running) return;
    setError(''); setRunning(true);
    setTurns([]); setSynthesis(null); setSynthMeta(null);
    setCurrentSession(null); setExportState({});

    const sid = 'ORQ-' + Date.now().toString(36).toUpperCase();
    const agents = activeAgents();
    const history = [];
    const t0 = Date.now();

    try {
      for (const agent of agents) {
        setThinking(agent.id);
        const aLang = agentLang(agent.id);
        const sys = agent.persona(aLang);
        const histBlock = history.length
          ? '\n\n' + (aLang === 'pl' ? 'DELIBERACJA:' : 'DELIBERATION SO FAR:') + '\n' +
            history.map(t => `[${t.name}]:\n${t.text}`).join('\n\n')
          : '';
        const qLabel = aLang === 'pl' ? 'PYTANIE' : 'QUESTION';
        const go = aLang === 'pl' ? 'Wnieś swój wkład.' : 'Deliver your contribution.';
        const userContent = `${qLabel}: "${query}"${histBlock}\n\n${go}`;

        const text = await callAgent(sys, userContent);
        const turn = {
          agentId: agent.id, glyph: agent.glyph, hue: agent.hue,
          name: agent.name[aLang], role: agent.role[aLang],
          text, sid,
          ts: new Date().toLocaleTimeString('pl-PL', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        };
        history.push(turn);
        setThinking(null);

        if (agent.id === 'synthesiser') {
          const meta = {
            sid, agents: agents.map(a => a.name[agentLang(a.id)]).join(' · '),
            lang: LANGS.find(l => l.v === lang)?.label,
            dur: Math.round((Date.now() - t0) / 1000), ts: turn.ts,
          };
          setSynthesis(text);
          setSynthMeta(meta);
          const session = { sid, query: query.trim(), turns: history, synthesis: text, meta };
          setCurrentSession(session);
          addSession({ sid, q: query.trim().slice(0, 55) + (query.length > 55 ? '…' : ''), turns: history, synthesis: text, meta });

          // Auto-export if configured
          if (settings.notionAutoSave && settings.notionDbId) {
            handleNotionExport(session, settings.notionDbId);
          }
          if (settings.n8nAutoSend && settings.n8nWebhookId) {
            handleN8nExport(session, settings.n8nWebhookId);
          }
        } else {
          setTurns(h => [...h, turn]);
        }
      }
    } catch (e) {
      setError('Deliberacja przerwana: ' + e.message);
    } finally {
      setRunning(false); setThinking(null);
    }
  };

  conveneRef.current = convene;

  const showToast = (msg, type = 'ok') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3200);
  };

  const handleNotionExport = async (session, dbId) => {
    const s = session || currentSession;
    if (!s) return;
    const db = dbId || settings.notionDbId;
    if (!db) { showToast('Brak Notion DB ID w ustawieniach', 'err'); return; }
    setExportState(p => ({ ...p, notion: 'loading' }));
    try {
      const page = await exportSessionToNotion(s, db);
      setExportState(p => ({ ...p, notion: 'ok' }));
      showToast('✓ Zapisano w Notion');
      setTimeout(() => setExportState(p => ({ ...p, notion: null })), 3000);
    } catch (e) {
      setExportState(p => ({ ...p, notion: 'err' }));
      showToast('Błąd Notion: ' + e.message, 'err');
    }
  };

  const handleN8nExport = async (session, webhookId) => {
    const s = session || currentSession;
    if (!s) return;
    const wh = webhookId || settings.n8nWebhookId;
    if (!wh) { showToast('Brak Webhook ID w ustawieniach', 'err'); return; }
    setExportState(p => ({ ...p, n8n: 'loading' }));
    try {
      await sendToN8n(wh, s);
      setExportState(p => ({ ...p, n8n: 'ok' }));
      showToast('✓ Wysłano do n8n');
      setTimeout(() => setExportState(p => ({ ...p, n8n: null })), 3000);
    } catch (e) {
      setExportState(p => ({ ...p, n8n: 'err' }));
      showToast('Błąd n8n: ' + e.message, 'err');
    }
  };

  const handleCopyJSON = () => {
    if (!currentSession) return;
    const json = JSON.stringify(currentSession, null, 2);
    navigator.clipboard.writeText(json).then(() => showToast('✓ Skopiowano JSON'));
  };

  const handleCopyMD = () => {
    if (!currentSession) return;
    const { sid, query, turns, synthesis, meta } = currentSession;
    const md = `# Oracle ${sid}\n\n**Pytanie:** ${query}\n\n---\n\n${
      turns.filter(t => t.agentId !== 'synthesiser').map(t =>
        `## ${t.glyph} ${t.name}\n*${t.role}*\n\n${t.text}`
      ).join('\n\n---\n\n')
    }\n\n---\n\n## Σ Synteza\n\n${synthesis}\n\n---\n*${meta?.agents} · ${meta?.dur}s · ${meta?.ts}*`;
    navigator.clipboard.writeText(md).then(() => showToast('✓ Skopiowano Markdown'));
  };

  const saveSettings = () => {
    setSettings(draftSettings);
    setLang(draftSettings.lang);
    setCount(draftSettings.agentCount);
    setDrawerOpen(false);
    showToast('✓ Ustawienia zapisane');
  };

  const loadSession = (s) => {
    setTurns(s.turns.filter(t => t.agentId !== 'synthesiser'));
    setSynthesis(s.synthesis);
    setSynthMeta(s.meta);
    setQuery(s.q);
    setCurrentSession(s);
    setExportState({});
    mainRef.current?.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const tAgent = thinking ? AGENTS.find(a => a.id === thinking) : null;
  const streamTurns = turns.filter(t => t.agentId !== 'synthesiser');

  const notionBtnClass = `exp-btn notion${exportState.notion === 'ok' ? ' success' : exportState.notion === 'err' ? ' error' : ''}`;
  const n8nBtnClass    = `exp-btn n8n${exportState.n8n === 'ok' ? ' success' : exportState.n8n === 'err' ? ' error' : ''}`;

  return (
    <>
      <style>{CSS}</style>
      <div className="shell">

        {/* TOP BAR */}
        <div className="topbar">
          <div className="brand">
            <div className="brand-q">Q</div>
            <div className="brand-text">
              <div className="brand-name">Quadrance</div>
              <div className="brand-sub">The Oracle</div>
            </div>
          </div>
          {running && <div className="sdot" />}
          <button className="icon-btn" onClick={() => { setDraft(settings); setDrawerOpen(true); }} title="Ustawienia">⚙</button>
        </div>

        {/* SESSION HISTORY */}
        {sessions.length > 0 && (
          <div className="session-bar">
            <span className="sbar-label">Historia</span>
            {sessions.map(s => (
              <div key={s.sid} className="sbar-chip" onClick={() => loadSession(s)} title={s.q}>
                {s.sid}
              </div>
            ))}
          </div>
        )}

        {/* ERROR */}
        {error && <div className="err-bar">{error}</div>}

        {/* MAIN SCROLL */}
        <div className="main" ref={mainRef}>
          {streamTurns.length === 0 && !tAgent && !synthesis ? (
            <div className="empty">
              <div className="empty-icon">⊕</div>
              <div className="empty-txt">Rada oczekuje<br/>na pytanie</div>
            </div>
          ) : (
            <>
              {streamTurns.map((t, i) => (
                <div key={`${t.sid}-${i}`} className="turn"
                  style={{ '--a-hue': t.hue, animationDelay: `${i * 0.03}s` }}>
                  <div className="turn-left">
                    <div className="t-badge">{t.glyph}</div>
                    {i < streamTurns.length - 1 && <div className="t-thread" />}
                  </div>
                  <div className="t-body">
                    <div className="t-meta">
                      <span className="t-name">{t.name}</span>
                      <span className="t-role">/ {t.role}</span>
                      <span className="t-ts">{t.ts}</span>
                    </div>
                    <div className="t-text">{t.text}</div>
                  </div>
                </div>
              ))}

              {tAgent && (
                <div className="thinking" style={{ '--a-hue': tAgent.hue }}>
                  <div className="turn-left"><div className="t-badge">{tAgent.glyph}</div></div>
                  <div className="dots">
                    <div className="dot"/><div className="dot"/><div className="dot"/>
                    <span className="think-lbl">{tAgent.name[agentLang(tAgent.id)]} deliberuje…</span>
                  </div>
                </div>
              )}

              {synthesis && (
                <div className="synth-card">
                  <div className="synth-head">
                    <div className="synth-icon">Σ</div>
                    <div className="synth-title">Synteza</div>
                    {synthMeta && <div className="synth-id">{synthMeta.sid}</div>}
                  </div>
                  <div className="synth-text">{synthesis}</div>
                  {synthMeta && (
                    <div className="synth-meta">
                      <div>{synthMeta.agents}</div>
                      <div>{synthMeta.lang} · {synthMeta.dur}s · {synthMeta.ts}</div>
                    </div>
                  )}

                  {/* EXPORT ACTIONS */}
                  <div className="divider" style={{ marginTop: 14 }} />
                  <div className="export-row">
                    <button className={notionBtnClass}
                      onClick={() => handleNotionExport()}
                      disabled={exportState.notion === 'loading' || !settings.notionDbId}>
                      {exportState.notion === 'loading' ? '…' : exportState.notion === 'ok' ? '✓' : exportState.notion === 'err' ? '✗' : '📓'}
                      {exportState.notion === 'loading' ? 'Notion…' : 'Notion'}
                    </button>
                    <button className={n8nBtnClass}
                      onClick={() => handleN8nExport()}
                      disabled={exportState.n8n === 'loading' || !settings.n8nWebhookId}>
                      {exportState.n8n === 'loading' ? '…' : exportState.n8n === 'ok' ? '✓' : exportState.n8n === 'err' ? '✗' : '⚡'}
                      {exportState.n8n === 'loading' ? 'n8n…' : 'n8n'}
                    </button>
                    <button className="exp-btn" onClick={handleCopyJSON}>{ '{ }' } JSON</button>
                    <button className="exp-btn" onClick={handleCopyMD}>✎ MD</button>
                  </div>
                </div>
              )}
            </>
          )}
          <div ref={bottomRef} />
          <pb />
        </div>

        {/* QUERY AREA */}
        <div className="qarea">
          <div className="crow">
            <select className="sel" value={lang} onChange={e => setLang(e.target.value)} disabled={running}>
              {LANGS.map(l => <option key={l.v} value={l.v}>{l.flag} {l.label}</option>)}
            </select>
            <div className="pills">
              {[3,4,5].map(n => (
                <div key={n} className={`pill${count===n?' on':''}`}
                  onClick={() => !running && setCount(n)}>
                  {n}
                </div>
              ))}
            </div>
            <div className="agent-glyphs">
              {activeAgents().map(a => (
                <span key={a.id} className="ag" style={{ '--a-hue': a.hue }}>{a.glyph}</span>
              ))}
            </div>
          </div>
          <div className="qrow">
            <textarea className="qi" value={query} rows={2} disabled={running}
              placeholder={lang === 'pl' ? 'Opisz problem lub pytanie…' : lang === 'en' ? 'Describe the problem…' : 'Wpisz pytanie po polsku…'}
              onChange={e => setQuery(e.target.value)}
              onKeyDown={e => { if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) convene(); }}
            />
            <button className="send-btn" onClick={convene} disabled={running || !query.trim()}>
              {running ? '⏳' : '▶'}
            </button>
          </div>
        </div>

        {/* SETTINGS DRAWER */}
        {drawerOpen && (
          <>
            <div className="drawer-overlay" onClick={() => setDrawerOpen(false)} />
            <div className="drawer">
              <div className="drawer-head">
                <span className="drawer-title">Ustawienia</span>
                <button className="close-btn" onClick={() => setDrawerOpen(false)}>✕</button>
              </div>

              {/* DEFAULTS */}
              <div className="section-label">Domyślne</div>
              <div className="field-label">Język deliberacji</div>
              <select className="sel" style={{ width: '100%' }}
                value={draftSettings.lang}
                onChange={e => setDraft(p => ({ ...p, lang: e.target.value }))}>
                {LANGS.map(l => <option key={l.v} value={l.v}>{l.flag} {l.label}</option>)}
              </select>
              <div className="field-label">Liczba agentów</div>
              <div className="pills">
                {[3,4,5].map(n => (
                  <div key={n} className={`pill${draftSettings.agentCount===n?' on':''}`}
                    onClick={() => setDraft(p => ({ ...p, agentCount: n }))}>
                    {n}
                  </div>
                ))}
              </div>

              {/* NOTION */}
              <div className="section-label">Notion</div>
              <div className="field-label">Database ID</div>
              <input className="dinput" type="text"
                placeholder="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
                value={draftSettings.notionDbId || ''}
                onChange={e => setDraft(p => ({ ...p, notionDbId: e.target.value.trim() }))}
              />
              <div className="hint">ID bazy Notion gdzie zapisywać sesje Oracle.<br/>Kopiuj z URL: notion.so/.../<b>ID</b>?v=...</div>
              <div className="toggle-row">
                <span className="toggle-label">Auto-zapis po deliberacji</span>
                <button className={`toggle${draftSettings.notionAutoSave?' on':''}`}
                  onClick={() => setDraft(p => ({ ...p, notionAutoSave: !p.notionAutoSave }))} />
              </div>

              {/* N8N */}
              <div className="section-label">n8n</div>
              <div className="field-label">Webhook ID</div>
              <input className="dinput" type="text"
                placeholder="np. oracle-output"
                value={draftSettings.n8nWebhookId || ''}
                onChange={e => setDraft(p => ({ ...p, n8nWebhookId: e.target.value.trim() }))}
              />
              <div className="hint">Webhook ID z n8n (bez /webhook/).<br/>n8n URL ustawiony w Vercel env: N8N_BASE_URL</div>
              <div className="toggle-row">
                <span className="toggle-label">Auto-wyślij do n8n po deliberacji</span>
                <button className={`toggle${draftSettings.n8nAutoSend?' on':''}`}
                  onClick={() => setDraft(p => ({ ...p, n8nAutoSend: !p.n8nAutoSend }))} />
              </div>

              <button className="save-btn" onClick={saveSettings}>Zapisz ustawienia</button>

              {/* DANGER */}
              <div className="section-label" style={{ marginTop: 28, color: 'var(--red)' }}>Dane</div>
              <button className="exp-btn" style={{ width: '100%', marginTop: 8, borderColor: 'var(--red)', color: 'var(--red)' }}
                onClick={() => { clearSessions(); showToast('Historia wyczyszczona'); setDrawerOpen(false); }}>
                🗑 Wyczyść historię sesji
              </button>
            </div>
          </>
        )}

        {/* TOAST */}
        {toast && <div className={`toast ${toast.type}`}>{toast.msg}</div>}

      </div>
    </>
  );
}
