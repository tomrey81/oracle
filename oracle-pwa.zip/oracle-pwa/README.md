# Oracle PWA — Quadrance

AI Expert Council. Progressive Web App. Instalowalna na Android.

## Wdrożenie na Vercel (15 minut)

### 1. Repozytorium

```bash
git init
git add .
git commit -m "Oracle PWA v1"
```

Wrzuć na GitHub (nowe repo: `oracle-pwa`).

### 2. Vercel

1. Idź na vercel.com → New Project → importuj repo
2. Framework: **Vite**
3. Build command: `npm run build`
4. Output directory: `dist`

### 3. Environment Variables (Vercel → Settings → Environment Variables)

| Zmienna | Wartość |
|---|---|
| `ANTHROPIC_API_KEY` | twój klucz Anthropic |
| `NOTION_TOKEN` | Integration token z notion.so/my-integrations |
| `N8N_BASE_URL` | `https://tomrey.app.n8n.cloud` |
| `N8N_API_KEY` | opcjonalnie, jeśli masz Basic Auth na webhookach |

### 4. Notion — przygotowanie bazy

Utwórz nową bazę danych w Notion z polami:
- **Name** (Title)
- **Query** (Rich text)
- **Session** (Rich text)
- **Agents** (Rich text)
- **Language** (Select: Polski, English, Mixed)
- **Confidence** (Select: HIGH, MEDIUM, LOW, Unknown)
- **Date** (Date)

Udostępnij bazę swojej integracji (Share → Add connections → wybierz integrację).

Skopiuj ID bazy z URL: `notion.so/twoja-przestrzen/`**`ID-BAZY`**`?v=...`

Wklej ID w Oracle → Ustawienia → Notion Database ID.

### 5. n8n — trigger z Oracle

Oracle wysyła na webhook następujący JSON:

```json
{
  "oracle_session": {
    "session_id": "ORQ-ABC123",
    "timestamp": "2026-03-06T10:00:00Z",
    "query": "pytanie",
    "language": "Mixed",
    "agents": "Architekt · Analityk · ...",
    "duration_seconds": 45,
    "confidence": "HIGH",
    "turns": [...],
    "synthesis": "...",
    "first_action": "..."
  },
  "session_id": "ORQ-ABC123",
  "query": "pytanie",
  "synthesis": "...",
  "confidence": "HIGH",
  "first_action": "...",
  "timestamp": "..."
}
```

### 6. n8n → Oracle (trigger deliberacji z workflow)

Możesz uruchomić Oracle z n8n wysyłając HTTP Request na:

```
https://twoja-aplikacja.vercel.app/?n8n_query=PYTANIE&n8n_auto=1&n8n_lang=mixed&n8n_agents=5
```

### 7. Instalacja na Android

1. Otwórz `https://twoja-aplikacja.vercel.app` w Chrome na Androidzie
2. Menu (⋮) → **Dodaj do ekranu głównego**
3. Oracle działa jak natywna aplikacja

---

## Lokalne uruchomienie

```bash
npm install
npm run dev
```

Uwaga: API keys muszą być w `.env.local`:
```
VITE_DEV_MODE=true
```
W trybie dev API calls idą bezpośrednio (bez serverless functions).
