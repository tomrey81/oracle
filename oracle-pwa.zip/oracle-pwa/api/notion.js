export default async function handler(req, res) {
  if (req.method === 'OPTIONS') return res.status(200).end();

  const { method = 'GET', path = '', body } = req.body || {};
  const notionPath = path || req.query.path || '';

  try {
    const response = await fetch(`https://api.notion.com/v1/${notionPath}`, {
      method,
      headers: {
        'Authorization': `Bearer ${process.env.NOTION_TOKEN}`,
        'Content-Type': 'application/json',
        'Notion-Version': '2022-06-28',
      },
      ...(body ? { body: JSON.stringify(body) } : {}),
    });

    const data = await response.json();
    return res.status(response.status).json(data);
  } catch (e) {
    return res.status(500).json({ error: e.message });
  }
}
