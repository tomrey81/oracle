export default async function handler(req, res) {
  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const { webhookId, payload } = req.body || {};
  const baseUrl = process.env.N8N_BASE_URL; // e.g. https://tomrey.app.n8n.cloud

  if (!webhookId || !baseUrl) {
    return res.status(400).json({ error: 'Missing webhookId or N8N_BASE_URL' });
  }

  try {
    const response = await fetch(`${baseUrl}/webhook/${webhookId}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(process.env.N8N_API_KEY ? { 'X-N8N-API-KEY': process.env.N8N_API_KEY } : {}),
      },
      body: JSON.stringify(payload),
    });

    const text = await response.text();
    let data;
    try { data = JSON.parse(text); } catch { data = { raw: text }; }
    return res.status(response.status).json(data);
  } catch (e) {
    return res.status(500).json({ error: e.message });
  }
}
